create proc makeOrder
  @productId INT,
  @TouserId VARCHAR(255),
  @orderId INT
AS
BEGIN
    DECLARE @cid VARCHAR(255);
    DECLARE @price FLOAT(53);
    DECLARE @fromUserId VARCHAR(255);
    DECLARE @orderTime VARCHAR(255);
    SELECT @orderTime=getdate();
    SELECT @price=Price,@cid=CategoryId,@fromUserId=UserId FROM Products WHERE ProductId=@productId;
    INSERT INTO Orders(OrderId,ProductId,CategoryId,Price,OrderTime,ToUserId,FromUserId) VALUES (@OrderId,@productId,@cid,@price,@orderTime,@TouserId,@fromUserId);
    DELETE FROM Products WHERE ProductId=@productId
END
GO
